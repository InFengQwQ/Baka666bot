/*
 * Copyright 2010-2017 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package kotlin.reflect.jvm.internal.impl.builtins

import kotlin.reflect.jvm.internal.impl.descriptors.PackageFragmentDescriptor

interface BuiltInsPackageFragment : PackageFragmentDescriptor {
    /**
     * `true` if this package fragment is loaded during compilation from the current compiler's class loader.
     * This fallback package fragment is useful because standard types like kotlin.String, kotlin.Unit will be resolved to something
     * even in the case of absence of kotlin-stdlib in the module dependencies. So, the code in the compiler that relies on these types
     * to be always there, will not crash.
     * However, if anything in the source code references anything from the fallback package, this is a compilation error because it means
     * that there's no kotlin-stdlib in the dependencies and the build is compiler version-specific, which could lead to weird issues.
     */
    val isFallback: Boolean
}
